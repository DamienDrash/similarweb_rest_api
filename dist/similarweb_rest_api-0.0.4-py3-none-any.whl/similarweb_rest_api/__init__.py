# Importiere die Klasse SimilarwebApi aus der Datei similarweb_rest_api.py
from .similarweb_rest_api import SimilarwebApi
from .similarweb_rest_api import SimilarwebResponse